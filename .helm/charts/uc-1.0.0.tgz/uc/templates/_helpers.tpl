{{- define "uc.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "uc.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := include "uc.name" . -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "uc.labels" -}}
helm.sh/chart: {{ include "uc.chart" . }}
app.kubernetes.io/name: {{ include "uc.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Chart.AppVersion }}
app.kubernetes.io/version: {{ . | quote }}
{{- end }}
{{- end -}}

{{- define "uc.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" -}}
{{- end -}}

{{- define "uc.selectorLabels" -}}
app.kubernetes.io/name: {{ include "uc.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "uc.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "uc.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{- define "uc.probe" -}}
{{- if eq .type "http" }}
httpGet:
  path: {{ .path }}
  port: {{ .port }}
{{- else if eq .type "tcp" }}
tcpSocket:
  port: {{ .port }}
{{- else if eq .type "exec" }}
exec:
  command:
    {{- toYaml .command | nindent 4 }}
{{- end }}
initialDelaySeconds: {{ .initDelay | default 5 }}
periodSeconds: {{ .period | default 10 }}
timeoutSeconds: {{ .timeout | default 3 }}
failureThreshold: {{ .threshold | default 3 }}
{{- end }}

{{- define "uc.container" -}}
name: {{ include "uc.name" . }}
image: {{ tpl .Values.image $ }}
imagePullPolicy: {{ .Values.imagePullPolicy }}
{{- with .Values.command }}
command:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.args }}
args:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.containerSecurityContext }}
securityContext:
  {{- toYaml . | nindent 2 }}
{{- end }}
env:
{{- range $key, $value := .Values.envs | default dict }}
  - name: {{ $key }}
    value: {{ tpl ($value | toString) $ | quote }}
{{- end }}
{{- range $name, $secret := .Values.secrets | default dict }}
{{- range $key, $value := $secret.data | default dict }}
{{- if $value.env }}
  - name: {{ $value.env }}
    valueFrom:
      secretKeyRef:
        name: {{ printf "%s-%s" $.Release.Name $name }}
        key: {{ $key }}
{{- end }}
{{- end }}
{{- end }}
ports:
{{- range $name, $endpoint := .Values.endpoints.ClusterIP | default dict }}
  - name: {{ $name }}
    containerPort: {{ $endpoint.containerPort | default $endpoint.port | int }}
    protocol: {{ $endpoint.protocol | default "TCP" }}
{{- end }}
{{- with .Values.resources }}
resources:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- if .Values.readinessProbe.enabled }}
readinessProbe:
  {{- include "uc.probe" .Values.readinessProbe | nindent 2 }}
{{- end }}
{{- if .Values.livenessProbe.enabled }}
livenessProbe:
  {{- include "uc.probe" .Values.livenessProbe | nindent 2 }}
{{- end }}
{{- if .Values.volumeMounts }}
volumeMounts:
  {{- toYaml .Values.volumeMounts | nindent 2 }}
{{- else if or .Values.persistence.existingClaim .Values.persistence.createClaim .Values.persistence.enabled }}
volumeMounts:
  - name: data
    mountPath: {{ .Values.persistence.mountPath | default "/data" }}
{{- end }}
{{- end -}}
